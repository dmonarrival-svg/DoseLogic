import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StackProvider, useStack } from './src/context/StackContext';
import StackScreen from './src/screens/StackScreen';
import AnalysisScreen from './src/screens/AnalysisScreen';
import NutrientsScreen from './src/screens/NutrientsScreen';
import { Colors, Radius, Spacing } from './src/theme';

const Tab = createBottomTabNavigator();

// Custom tab bar
function DoseLogicTabBar({ state, descriptors, navigation }) {
  const { getSummary } = useStack();
  const summary = getSummary();

  const tabs = [
    { name: 'Stack', icon: '⬛', activeIcon: '🟪', label: 'Stack' },
    { name: 'Analysis', icon: '🔬', activeIcon: '🔬', label: 'Analysis' },
    { name: 'Nutrients', icon: '📊', activeIcon: '📊', label: 'Nutrients' },
  ];

  // Custom SVG-style icons using Unicode shapes for clean look
  const icons = {
    Stack: (active) => (
      <View style={styles.tabIconWrap}>
        <View style={[styles.tabIconGrid, active && styles.tabIconGridActive]}>
          {[0,1,2,3].map(i => (
            <View key={i} style={[styles.tabIconSquare, active && styles.tabIconSquareActive]} />
          ))}
        </View>
      </View>
    ),
    Analysis: (active) => (
      <View style={styles.tabIconWrap}>
        <View style={[styles.tabIconCircle, active && styles.tabIconCircleActive]}>
          <View style={[styles.tabIconHand, active && styles.tabIconHandActive]} />
        </View>
      </View>
    ),
    Nutrients: (active) => (
      <View style={styles.tabIconWrap}>
        <View style={styles.tabIconBars}>
          {[4, 7, 5, 9].map((h, i) => (
            <View key={i} style={[styles.tabBar, { height: h, backgroundColor: active ? Colors.purpleBright : Colors.silverDim }]} />
          ))}
        </View>
      </View>
    ),
  };

  return (
    <View style={styles.tabBar}>
      {state.routes.map((route, index) => {
        const isFocused = state.index === index;
        const onPress = () => {
          const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
          if (!isFocused && !event.defaultPrevented) navigation.navigate(route.name);
        };

        // Badge for analysis tab
        const showBadge = route.name === 'Analysis' && summary.risks > 0;

        return (
          <TouchableOpacity key={route.key} style={styles.tabItem} onPress={onPress} activeOpacity={0.7}>
            <View style={styles.tabIconContainer}>
              {icons[route.name]?.(isFocused)}
              {showBadge && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{summary.risks}</Text>
                </View>
              )}
            </View>
            <Text style={[styles.tabLabel, isFocused && styles.tabLabelActive]}>
              {route.name}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

function AppNavigator() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        tabBar={props => <DoseLogicTabBar {...props} />}
        screenOptions={{ headerShown: false }}
      >
        <Tab.Screen name="Stack" component={StackScreen} />
        <Tab.Screen name="Analysis" component={AnalysisScreen} />
        <Tab.Screen name="Nutrients" component={NutrientsScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <StackProvider>
      <AppNavigator />
    </StackProvider>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    flexDirection: 'row',
    backgroundColor: 'rgba(13,8,24,0.97)',
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingTop: 10,
    paddingBottom: 28,
    paddingHorizontal: Spacing.xl,
  },
  tabItem: {
    flex: 1, alignItems: 'center', gap: 4,
  },
  tabIconContainer: { position: 'relative' },
  tabIconWrap: { width: 28, height: 24, alignItems: 'center', justifyContent: 'center' },

  tabIconGrid: { width: 18, height: 18, flexWrap: 'wrap', flexDirection: 'row', gap: 2 },
  tabIconGridActive: {},
  tabIconSquare: { width: 7, height: 7, borderRadius: 2, backgroundColor: Colors.silverDim },
  tabIconSquareActive: { backgroundColor: Colors.purpleBright },

  tabIconCircle: {
    width: 18, height: 18, borderRadius: 9,
    borderWidth: 1.5, borderColor: Colors.silverDim,
    alignItems: 'center', justifyContent: 'center',
  },
  tabIconCircleActive: { borderColor: Colors.purpleBright },
  tabIconHand: { width: 5, height: 5, borderRadius: 1, backgroundColor: Colors.silverDim, marginTop: -3, marginLeft: 3 },
  tabIconHandActive: { backgroundColor: Colors.purpleBright },

  tabIconBars: { flexDirection: 'row', alignItems: 'flex-end', gap: 2, height: 14 },
  tabBar2: { width: 4, borderRadius: 1 },

  tabLabel: { fontSize: 10, fontWeight: '500', color: Colors.silverDim },
  tabLabelActive: { color: Colors.purpleBright },

  badge: {
    position: 'absolute', top: -4, right: -8,
    backgroundColor: Colors.danger,
    borderRadius: Radius.full, minWidth: 16, height: 16,
    alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 3,
  },
  badgeText: { fontSize: 9, fontWeight: '700', color: Colors.white },
});
