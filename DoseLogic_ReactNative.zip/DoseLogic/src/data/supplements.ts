// src/data/supplements.ts

export type Category =
  | 'vitamin'
  | 'mineral'
  | 'weight'
  | 'gym'
  | 'amino'
  | 'nootropic'
  | 'sarm'
  | 'peptide';

export interface Supplement {
  id: string;
  name: string;
  cat: Category;
  unit: string;
  defaultDose: number;
  ul: number | null; // tolerable upper intake level
  nutrients: Record<string, number>;
  interactions: string[]; // ids of supplements that interact
  sarmFlag?: boolean;
  peptideFlag?: boolean;
  description?: string;
}

export const SUPPLEMENTS: Supplement[] = [
  // ─── VITAMINS ───────────────────────────────────────────────
  {
    id: 'vd3', name: 'Vitamin D3', cat: 'vitamin', unit: 'IU',
    defaultDose: 2000, ul: 4000, nutrients: { vitaminD: 2000 },
    interactions: ['vk2', 'calcium'],
    description: 'Fat-soluble vitamin critical for bone health, immune function, and mood regulation.',
  },
  {
    id: 'vk2', name: 'Vitamin K2 (MK-7)', cat: 'vitamin', unit: 'mcg',
    defaultDose: 100, ul: null, nutrients: { vitaminK: 100 },
    interactions: ['vd3'],
    description: 'Directs calcium to bones and away from arteries. Synergistic with D3.',
  },
  {
    id: 'vitc', name: 'Vitamin C', cat: 'vitamin', unit: 'mg',
    defaultDose: 500, ul: 2000, nutrients: { vitaminC: 500 },
    interactions: ['iron'],
    description: 'Antioxidant, immune support, collagen synthesis, iron absorption enhancer.',
  },
  {
    id: 'vitb12', name: 'Vitamin B12', cat: 'vitamin', unit: 'mcg',
    defaultDose: 1000, ul: null, nutrients: { vitB12: 1000 },
    interactions: ['folate'],
    description: 'Essential for nerve function, DNA synthesis, and red blood cell formation.',
  },
  {
    id: 'vitb6', name: 'Vitamin B6', cat: 'vitamin', unit: 'mg',
    defaultDose: 10, ul: 100, nutrients: { vitB6: 10 },
    interactions: ['folate'],
    description: 'Amino acid metabolism, neurotransmitter synthesis, hormone regulation.',
  },
  {
    id: 'folate', name: 'Folate / B9', cat: 'vitamin', unit: 'mcg',
    defaultDose: 400, ul: 1000, nutrients: { folate: 400 },
    interactions: ['vitb12', 'vitb6'],
    description: 'DNA synthesis, methylation, fetal development. Works with B12.',
  },
  {
    id: 'vita', name: 'Vitamin A', cat: 'vitamin', unit: 'IU',
    defaultDose: 5000, ul: 10000, nutrients: { vitaminA: 5000 },
    interactions: [],
    description: 'Vision, immune function, skin health. Toxic in excess.',
  },
  {
    id: 'vite', name: 'Vitamin E', cat: 'vitamin', unit: 'IU',
    defaultDose: 400, ul: 1500, nutrients: { vitaminE: 400 },
    interactions: ['omega3'],
    description: 'Fat-soluble antioxidant. Mild blood-thinning at high doses.',
  },
  {
    id: 'omega3', name: 'Omega-3 (Fish Oil)', cat: 'vitamin', unit: 'g',
    defaultDose: 2, ul: null, nutrients: {},
    interactions: ['vite'],
    description: 'EPA/DHA for cardiovascular health, inflammation, brain function.',
  },
  {
    id: 'coq10', name: 'CoQ10', cat: 'vitamin', unit: 'mg',
    defaultDose: 200, ul: null, nutrients: {},
    interactions: [],
    description: 'Mitochondrial energy production, antioxidant. Important with statin use.',
  },
  {
    id: 'probiotics', name: 'Probiotics', cat: 'vitamin', unit: 'B CFU',
    defaultDose: 10, ul: null, nutrients: {},
    interactions: [],
    description: 'Gut microbiome support, digestion, immunity.',
  },

  // ─── MINERALS ───────────────────────────────────────────────
  {
    id: 'calcium', name: 'Calcium', cat: 'mineral', unit: 'mg',
    defaultDose: 500, ul: 2500, nutrients: { calcium: 500 },
    interactions: ['vd3', 'iron', 'magnesium'],
    description: 'Bone density, muscle contraction, nerve signaling.',
  },
  {
    id: 'magnesium', name: 'Magnesium', cat: 'mineral', unit: 'mg',
    defaultDose: 400, ul: 350, nutrients: { magnesium: 400 },
    interactions: ['calcium', 'zinc'],
    description: '300+ enzymatic reactions. Sleep, muscle recovery, insulin sensitivity.',
  },
  {
    id: 'zinc', name: 'Zinc', cat: 'mineral', unit: 'mg',
    defaultDose: 15, ul: 40, nutrients: { zinc: 15 },
    interactions: ['copper', 'magnesium'],
    description: 'Immune function, testosterone production, wound healing.',
  },
  {
    id: 'iron', name: 'Iron', cat: 'mineral', unit: 'mg',
    defaultDose: 18, ul: 45, nutrients: { iron: 18 },
    interactions: ['calcium', 'vitc'],
    description: 'Hemoglobin, oxygen transport, energy metabolism.',
  },
  {
    id: 'selenium', name: 'Selenium', cat: 'mineral', unit: 'mcg',
    defaultDose: 200, ul: 400, nutrients: { selenium: 200 },
    interactions: [],
    description: 'Thyroid function, antioxidant defense, immune support.',
  },
  {
    id: 'copper', name: 'Copper', cat: 'mineral', unit: 'mg',
    defaultDose: 1, ul: 10, nutrients: { copper: 1 },
    interactions: ['zinc'],
    description: 'Iron metabolism, connective tissue, energy production.',
  },
  {
    id: 'iodine', name: 'Iodine', cat: 'mineral', unit: 'mcg',
    defaultDose: 150, ul: 1100, nutrients: { iodine: 150 },
    interactions: [],
    description: 'Thyroid hormone synthesis, metabolism regulation.',
  },
  {
    id: 'chromium', name: 'Chromium Picolinate', cat: 'mineral', unit: 'mcg',
    defaultDose: 200, ul: null, nutrients: { chromium: 200 },
    interactions: ['berberine'],
    description: 'Insulin sensitivity, glucose metabolism, carb cravings.',
  },

  // ─── WEIGHT LOSS ────────────────────────────────────────────
  {
    id: 'caffeinesupp', name: 'Caffeine', cat: 'weight', unit: 'mg',
    defaultDose: 200, ul: 400, nutrients: { caffeine: 200 },
    interactions: ['preworkout', 'yohimbine', 'synephrine', 'ltheanine'],
    description: 'Stimulant, thermogenic, performance and focus enhancer.',
  },
  {
    id: 'greentea', name: 'Green Tea Extract', cat: 'weight', unit: 'mg',
    defaultDose: 400, ul: 800, nutrients: { egcg: 400 },
    interactions: ['caffeinesupp'],
    description: 'EGCG antioxidant, mild thermogenic, fat oxidation support.',
  },
  {
    id: 'garcinia', name: 'Garcinia Cambogia', cat: 'weight', unit: 'mg',
    defaultDose: 1500, ul: null, nutrients: {},
    interactions: [],
    description: 'HCA may suppress appetite and inhibit fat storage enzyme.',
  },
  {
    id: 'berberine', name: 'Berberine', cat: 'weight', unit: 'mg',
    defaultDose: 500, ul: null, nutrients: {},
    interactions: ['chromium'],
    description: 'AMPK activator. Blood sugar regulation, similar mechanism to metformin.',
  },
  {
    id: 'cla', name: 'CLA', cat: 'weight', unit: 'g',
    defaultDose: 3, ul: null, nutrients: {},
    interactions: [],
    description: 'Conjugated linoleic acid. Modest fat loss, lean mass preservation.',
  },
  {
    id: 'yohimbine', name: 'Yohimbine', cat: 'weight', unit: 'mg',
    defaultDose: 5, ul: 30, nutrients: {},
    interactions: ['caffeinesupp', 'preworkout', 'synephrine'],
    description: 'Alpha-2 antagonist. Targets stubborn fat. Strong CNS stimulant.',
  },
  {
    id: 'synephrine', name: 'Synephrine', cat: 'weight', unit: 'mg',
    defaultDose: 30, ul: null, nutrients: {},
    interactions: ['caffeinesupp', 'yohimbine'],
    description: 'Bitter orange extract. Thermogenic, appetite suppressant.',
  },

  // ─── GYM / PERFORMANCE ──────────────────────────────────────
  {
    id: 'creatine', name: 'Creatine Monohydrate', cat: 'gym', unit: 'g',
    defaultDose: 5, ul: null, nutrients: {},
    interactions: [],
    description: 'Most researched supplement. ATP regeneration, strength, muscle volume.',
  },
  {
    id: 'betaalanine', name: 'Beta-Alanine', cat: 'gym', unit: 'g',
    defaultDose: 3.2, ul: null, nutrients: {},
    interactions: [],
    description: 'Increases muscle carnosine. Reduces lactic acid, extends endurance.',
  },
  {
    id: 'preworkout', name: 'Pre-Workout', cat: 'gym', unit: 'serving',
    defaultDose: 1, ul: null, nutrients: { caffeine: 150 },
    interactions: ['caffeinesupp', 'yohimbine'],
    description: 'Multi-ingredient blend. Contains caffeine — stack carefully.',
  },
  {
    id: 'citrulline', name: 'L-Citrulline', cat: 'gym', unit: 'g',
    defaultDose: 6, ul: null, nutrients: {},
    interactions: ['arginine'],
    description: 'Nitric oxide precursor. Pump, blood flow, endurance.',
  },
  {
    id: 'arginine', name: 'L-Arginine', cat: 'gym', unit: 'g',
    defaultDose: 3, ul: null, nutrients: {},
    interactions: ['citrulline'],
    description: 'NO precursor. Citrulline is more bioavailable — avoid stacking both.',
  },

  // ─── AMINO ACIDS ────────────────────────────────────────────
  {
    id: 'bcaa', name: 'BCAAs', cat: 'amino', unit: 'g',
    defaultDose: 5, ul: null, nutrients: {},
    interactions: ['eaa'],
    description: 'Leucine, isoleucine, valine. Muscle protein synthesis, anti-catabolism.',
  },
  {
    id: 'eaa', name: 'EAAs (Essential Amino Acids)', cat: 'amino', unit: 'g',
    defaultDose: 10, ul: null, nutrients: {},
    interactions: ['bcaa'],
    description: 'Complete amino acid profile including BCAAs. Redundant to stack with BCAAs.',
  },
  {
    id: 'glutamine', name: 'L-Glutamine', cat: 'amino', unit: 'g',
    defaultDose: 5, ul: null, nutrients: {},
    interactions: [],
    description: 'Gut health, immune support, muscle recovery.',
  },
  {
    id: 'taurine', name: 'Taurine', cat: 'amino', unit: 'mg',
    defaultDose: 500, ul: null, nutrients: {},
    interactions: [],
    description: 'Cardiovascular function, hydration, can blunt stimulant side effects.',
  },
  {
    id: 'tyrosine', name: 'L-Tyrosine', cat: 'amino', unit: 'mg',
    defaultDose: 500, ul: null, nutrients: {},
    interactions: [],
    description: 'Dopamine/norepinephrine precursor. Focus under stress.',
  },

  // ─── NOOTROPICS ─────────────────────────────────────────────
  {
    id: 'nad', name: 'NAD+ / NMN', cat: 'nootropic', unit: 'mg',
    defaultDose: 500, ul: null, nutrients: {},
    interactions: [],
    description: 'NAD+ precursor. Cellular energy, longevity, DNA repair.',
  },
  {
    id: 'ashwagandha', name: 'Ashwagandha (KSM-66)', cat: 'nootropic', unit: 'mg',
    defaultDose: 300, ul: null, nutrients: {},
    interactions: ['melatonin'],
    description: 'Adaptogen. Cortisol reduction, stress, testosterone support.',
  },
  {
    id: 'lionsmane', name: "Lion's Mane", cat: 'nootropic', unit: 'mg',
    defaultDose: 500, ul: null, nutrients: {},
    interactions: [],
    description: 'NGF stimulator. Nerve growth, cognition, neuroprotection.',
  },
  {
    id: 'rhodiola', name: 'Rhodiola Rosea', cat: 'nootropic', unit: 'mg',
    defaultDose: 400, ul: null, nutrients: {},
    interactions: ['fivehtp'],
    description: 'Adaptogen. Mental fatigue, endurance, mood stabilization.',
  },
  {
    id: 'alphabrain', name: 'Alpha-GPC', cat: 'nootropic', unit: 'mg',
    defaultDose: 300, ul: null, nutrients: {},
    interactions: ['racetam'],
    description: 'High-bioavailability choline source. Memory, focus, pairs with racetams.',
  },
  {
    id: 'racetam', name: 'Piracetam / Racetams', cat: 'nootropic', unit: 'mg',
    defaultDose: 1600, ul: null, nutrients: {},
    interactions: ['alphabrain'],
    description: 'Cognitive enhancement. Requires choline source to avoid headaches.',
  },
  {
    id: 'melatonin', name: 'Melatonin', cat: 'nootropic', unit: 'mg',
    defaultDose: 0.5, ul: null, nutrients: {},
    interactions: ['ashwagandha'],
    description: 'Sleep onset hormone. Use lowest effective dose (0.3–1 mg).',
  },
  {
    id: 'fivehtp', name: '5-HTP', cat: 'nootropic', unit: 'mg',
    defaultDose: 100, ul: null, nutrients: {},
    interactions: ['rhodiola'],
    description: 'Serotonin precursor. Mood, sleep, appetite regulation.',
  },
  {
    id: 'ltheanine', name: 'L-Theanine', cat: 'nootropic', unit: 'mg',
    defaultDose: 200, ul: null, nutrients: {},
    interactions: ['caffeinesupp'],
    description: 'Calming amino acid. Smooths caffeine, improves focus quality.',
  },
  {
    id: 'nac', name: 'NAC', cat: 'nootropic', unit: 'mg',
    defaultDose: 600, ul: null, nutrients: {},
    interactions: [],
    description: 'Glutathione precursor. Liver protection, antioxidant, OCD/addiction support.',
  },

  // ─── SARMs ──────────────────────────────────────────────────
  {
    id: 'lgd4033', name: 'LGD-4033 (Ligandrol)', cat: 'sarm', unit: 'mg',
    defaultDose: 10, ul: null, nutrients: {},
    interactions: ['rad140', 'yk11', 'mk677'],
    sarmFlag: true,
    description: 'Potent anabolic SARM. Significant lean mass gains. Strong suppression.',
  },
  {
    id: 'rad140', name: 'RAD-140 (Testolone)', cat: 'sarm', unit: 'mg',
    defaultDose: 10, ul: null, nutrients: {},
    interactions: ['lgd4033', 'yk11', 'mk677'],
    sarmFlag: true,
    description: 'High anabolic:androgenic ratio. Strength, aggression, suppression.',
  },
  {
    id: 'ostarine', name: 'Ostarine (MK-2866)', cat: 'sarm', unit: 'mg',
    defaultDose: 25, ul: null, nutrients: {},
    interactions: ['lgd4033', 'rad140'],
    sarmFlag: true,
    description: 'Mildest SARM. Lean muscle, joint health, cutting. Moderate suppression.',
  },
  {
    id: 'cardarine', name: 'Cardarine (GW-501516)', cat: 'sarm', unit: 'mg',
    defaultDose: 20, ul: null, nutrients: {},
    interactions: ['lgd4033'],
    sarmFlag: true,
    description: 'PPARδ agonist (not a true SARM). Endurance, fat oxidation. Cancer risk concerns.',
  },
  {
    id: 'yk11', name: 'YK-11', cat: 'sarm', unit: 'mg',
    defaultDose: 5, ul: null, nutrients: {},
    interactions: ['lgd4033', 'rad140'],
    sarmFlag: true,
    description: 'Myostatin inhibitor. Extreme mass. Significant hepatotoxicity risk.',
  },
  {
    id: 'mk677', name: 'MK-677 (Ibutamoren)', cat: 'sarm', unit: 'mg',
    defaultDose: 25, ul: null, nutrients: {},
    interactions: ['lgd4033', 'rad140', 'bpc157'],
    sarmFlag: true,
    description: 'GH secretagogue (not a true SARM). GH/IGF-1 elevation, sleep, recovery.',
  },
  {
    id: 'sr9009', name: 'SR9009 (Stenabolic)', cat: 'sarm', unit: 'mg',
    defaultDose: 20, ul: null, nutrients: {},
    interactions: [],
    sarmFlag: true,
    description: 'REV-ERB agonist. Endurance, fat loss, circadian rhythm modulation.',
  },
  {
    id: 'andarine', name: 'Andarine (S4)', cat: 'sarm', unit: 'mg',
    defaultDose: 25, ul: null, nutrients: {},
    interactions: ['lgd4033'],
    sarmFlag: true,
    description: 'Cutting SARM. Vision side effects (yellow tint) possible at higher doses.',
  },

  // ─── PEPTIDES ───────────────────────────────────────────────
  {
    id: 'bpc157', name: 'BPC-157', cat: 'peptide', unit: 'mcg',
    defaultDose: 250, ul: null, nutrients: {},
    interactions: ['mk677', 'tb500'],
    peptideFlag: true,
    description: 'Body protection compound. Accelerated healing, gut repair, angiogenesis.',
  },
  {
    id: 'tb500', name: 'TB-500', cat: 'peptide', unit: 'mg',
    defaultDose: 2.5, ul: null, nutrients: {},
    interactions: ['bpc157'],
    peptideFlag: true,
    description: 'Thymosin Beta-4. Injury recovery, muscle regeneration, flexibility.',
  },
  {
    id: 'igf1', name: 'IGF-1 LR3', cat: 'peptide', unit: 'mcg',
    defaultDose: 50, ul: null, nutrients: {},
    interactions: ['mk677'],
    peptideFlag: true,
    description: 'Insulin-like growth factor. Muscle hyperplasia, nutrient partitioning.',
  },
  {
    id: 'ghrp2', name: 'GHRP-2', cat: 'peptide', unit: 'mcg',
    defaultDose: 100, ul: null, nutrients: {},
    interactions: ['cjc1295'],
    peptideFlag: true,
    description: 'GH secretagogue. Pulsatile GH release, hunger stimulation.',
  },
  {
    id: 'cjc1295', name: 'CJC-1295', cat: 'peptide', unit: 'mcg',
    defaultDose: 100, ul: null, nutrients: {},
    interactions: ['ghrp2'],
    peptideFlag: true,
    description: 'GHRH analogue. Sustained GH elevation, synergistic with GHRP-2.',
  },
  {
    id: 'selank', name: 'Selank', cat: 'peptide', unit: 'mcg',
    defaultDose: 250, ul: null, nutrients: {},
    interactions: [],
    peptideFlag: true,
    description: 'Anxiolytic peptide. Anti-anxiety, cognitive enhancement, BDNF upregulation.',
  },
  {
    id: 'semax', name: 'Semax', cat: 'peptide', unit: 'mcg',
    defaultDose: 300, ul: null, nutrients: {},
    interactions: [],
    peptideFlag: true,
    description: 'Nootropic peptide. BDNF/NGF stimulation, focus, neuroprotection.',
  },
  {
    id: 'epitalon', name: 'Epithalon', cat: 'peptide', unit: 'mg',
    defaultDose: 10, ul: null, nutrients: {},
    interactions: [],
    peptideFlag: true,
    description: 'Telomerase activator. Anti-aging, pineal gland regulation, sleep.',
  },
  {
    id: 'aod9604', name: 'AOD-9604', cat: 'peptide', unit: 'mcg',
    defaultDose: 300, ul: null, nutrients: {},
    interactions: [],
    peptideFlag: true,
    description: 'HGH fragment. Lipolysis, fat loss without GH side effects.',
  },
];

// ─── INTERACTIONS DATABASE ──────────────────────────────────────────

export type Severity = 'ok' | 'warn' | 'danger';

export interface InteractionRecord {
  sev: Severity;
  text: string;
}

function key(a: string, b: string) {
  return [a, b].sort().join('+');
}

export const INTERACTIONS: Record<string, InteractionRecord> = {
  [key('vd3', 'vk2')]: { sev: 'ok', text: 'D3 and K2 work synergistically — D3 raises calcium absorption, K2 directs it to bones. Ideal pairing.' },
  [key('vd3', 'calcium')]: { sev: 'ok', text: 'D3 enhances calcium absorption. Purposeful stack — keep total calcium under 2,500 mg/day.' },
  [key('calcium', 'magnesium')]: { sev: 'warn', text: 'These compete for absorption. Space doses at least 2 hours apart for best results.' },
  [key('calcium', 'iron')]: { sev: 'warn', text: 'Calcium significantly reduces iron absorption. Separate by at least 2 hours.' },
  [key('vitc', 'iron')]: { sev: 'ok', text: 'Vitamin C dramatically boosts non-heme iron absorption. Beneficial pairing for iron deficiency.' },
  [key('zinc', 'copper')]: { sev: 'warn', text: 'High-dose zinc depletes copper over time. If taking zinc >40 mg/day, add copper supplementation.' },
  [key('zinc', 'magnesium')]: { sev: 'ok', text: 'ZMA-style stack. Competitive at high doses — consider timing separately.' },
  [key('caffeinesupp', 'preworkout')]: { sev: 'danger', text: 'Double caffeine detected. Combined intake may exceed 400 mg. Risk: elevated heart rate, anxiety, and insomnia.' },
  [key('caffeinesupp', 'yohimbine')]: { sev: 'danger', text: 'Caffeine + Yohimbine is a powerful CNS stimulant stack. Can cause acute hypertension and palpitations.' },
  [key('yohimbine', 'synephrine')]: { sev: 'danger', text: 'Both are sympathomimetics. Combined cardiovascular stress risk is significant — use with extreme caution.' },
  [key('caffeinesupp', 'synephrine')]: { sev: 'warn', text: 'Both raise heart rate and blood pressure. Monitor cardiovascular response closely.' },
  [key('preworkout', 'yohimbine')]: { sev: 'danger', text: 'Pre-workout caffeine + yohimbine: high risk of cardiovascular stress and anxiety.' },
  [key('lgd4033', 'rad140')]: { sev: 'danger', text: 'Two androgenic SARMs compounds suppression significantly. PCT (post-cycle therapy) is strongly advised.' },
  [key('lgd4033', 'yk11')]: { sev: 'danger', text: 'LGD + YK-11: high-suppression stack. Liver stress and hormonal disruption risk is elevated.' },
  [key('rad140', 'yk11')]: { sev: 'danger', text: 'Aggressive androgenic stack. Significant HPTA suppression. PCT and liver support essential.' },
  [key('lgd4033', 'mk677')]: { sev: 'warn', text: 'SARM + MK-677: monitor IGF-1, fasting glucose, and suppression bloodwork.' },
  [key('rad140', 'mk677')]: { sev: 'warn', text: 'Monitor IGF-1 levels and watch for water retention and insulin sensitivity changes.' },
  [key('bpc157', 'tb500')]: { sev: 'ok', text: 'Popular healing peptide stack. Synergistic for injury recovery. Generally safe to combine.' },
  [key('ghrp2', 'cjc1295')]: { sev: 'ok', text: 'Synergistic GH secretagogue stack. Combined pulsatile GH release is significantly amplified.' },
  [key('bcaa', 'eaa')]: { sev: 'warn', text: 'EAAs already contain BCAAs. Stacking both is redundant — overlapping leucine/isoleucine/valine.' },
  [key('citrulline', 'arginine')]: { sev: 'warn', text: 'Both raise nitric oxide via the same pathway. Citrulline converts to arginine — stacking is largely redundant.' },
  [key('alphabrain', 'racetam')]: { sev: 'ok', text: 'Classic nootropic stack. Alpha-GPC provides choline to prevent racetam-induced depletion.' },
  [key('vitb12', 'folate')]: { sev: 'ok', text: 'B12 and folate work together in methylation. Synergistic for neurological and cardiovascular health.' },
  [key('ltheanine', 'caffeinesupp')]: { sev: 'ok', text: "One of the most evidence-backed nootropic pairings. Theanine smooths caffeine's jitters and sharpens focus." },
  [key('omega3', 'vite')]: { sev: 'warn', text: 'Both have mild blood-thinning effects. At high doses, combined anticoagulant effect could be significant.' },
  [key('ashwagandha', 'melatonin')]: { sev: 'ok', text: 'Both support sleep and stress modulation. Generally safe to combine; may enhance relaxation.' },
  [key('fivehtp', 'rhodiola')]: { sev: 'warn', text: 'Both affect serotonin pathways. Risk of serotonin-related side effects at high doses.' },
  [key('bpc157', 'mk677')]: { sev: 'warn', text: 'BPC-157 + MK-677: GH secretagogue + healing peptide. Monitor GH/IGF-1 levels.' },
};

// ─── NUTRIENT REFERENCE LIMITS ──────────────────────────────────────

export interface NutrientRef {
  label: string;
  unit: string;
  ul: number | null;
}

export const NUTRIENT_REFS: Record<string, NutrientRef> = {
  vitaminD: { label: 'Vitamin D', unit: 'IU', ul: 4000 },
  vitaminC: { label: 'Vitamin C', unit: 'mg', ul: 2000 },
  vitaminK: { label: 'Vitamin K', unit: 'mcg', ul: null },
  vitB12: { label: 'Vitamin B12', unit: 'mcg', ul: null },
  vitB6: { label: 'Vitamin B6', unit: 'mg', ul: 100 },
  folate: { label: 'Folate', unit: 'mcg', ul: 1000 },
  vitaminA: { label: 'Vitamin A', unit: 'IU', ul: 10000 },
  vitaminE: { label: 'Vitamin E', unit: 'IU', ul: 1500 },
  calcium: { label: 'Calcium', unit: 'mg', ul: 2500 },
  magnesium: { label: 'Magnesium', unit: 'mg', ul: 350 },
  zinc: { label: 'Zinc', unit: 'mg', ul: 40 },
  iron: { label: 'Iron', unit: 'mg', ul: 45 },
  selenium: { label: 'Selenium', unit: 'mcg', ul: 400 },
  caffeine: { label: 'Caffeine', unit: 'mg', ul: 400 },
  egcg: { label: 'EGCG', unit: 'mg', ul: 800 },
  chromium: { label: 'Chromium', unit: 'mcg', ul: null },
  iodine: { label: 'Iodine', unit: 'mcg', ul: 1100 },
};
