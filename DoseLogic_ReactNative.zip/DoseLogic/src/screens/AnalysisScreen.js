import React from 'react';
import { View, Text, ScrollView, StyleSheet, SafeAreaView, StatusBar } from 'react-native';
import { useStack } from '../context/StackContext';
import { AnalysisCard, SectionLabel, EmptyState } from '../components';
import { Colors, Spacing, Radius } from '../theme';

export default function AnalysisScreen() {
  const { stack, getInteractions, getULFlags } = useStack();

  const interactions = getInteractions();
  const ulFlags = getULFlags();
  const sarms = stack.filter(s => s.sarmFlag);
  const peptides = stack.filter(s => s.peptideFlag);

  const dangers = interactions.filter(x => x.sev === 'danger');
  const warns = interactions.filter(x => x.sev === 'warn');
  const oks = interactions.filter(x => x.sev === 'ok');

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bgDeep} />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.screenTitle}>Analysis</Text>

        {stack.length === 0 ? (
          <EmptyState emoji="🔬" text="Add supplements to your stack to see detailed interaction and risk analysis" />
        ) : (
          <>
            {/* SARMs warning banner */}
            {sarms.length > 0 && (
              <View style={styles.sarmBanner}>
                <Text style={styles.sarmBannerIcon}>⚠️</Text>
                <View style={styles.sarmBannerBody}>
                  <Text style={styles.sarmBannerTitle}>
                    SARMs detected in stack ({sarms.length} compound{sarms.length > 1 ? 's' : ''})
                  </Text>
                  <Text style={styles.sarmBannerText}>
                    SARMs are not FDA-approved. Risks include hormonal suppression, liver stress, and cardiovascular strain. 
                    Bloodwork (testosterone, LH, FSH, liver enzymes) is strongly recommended. PCT may be required post-cycle.
                  </Text>
                </View>
              </View>
            )}

            {/* Upper limit violations */}
            {ulFlags.length > 0 && (
              <>
                <SectionLabel>Dose Exceeds Upper Limit</SectionLabel>
                {ulFlags.map(s => (
                  <AnalysisCard
                    key={s.id}
                    sev="danger"
                    title={`${s.name} — above safe upper limit`}
                    text={`Your dose (${s.dose} ${s.unit}) exceeds the tolerable upper intake level of ${s.ul} ${s.unit}. Risk of toxicity increases above UL.`}
                  />
                ))}
              </>
            )}

            {/* Danger interactions */}
            {dangers.length > 0 && (
              <>
                <SectionLabel>Danger — Avoid or Monitor Closely</SectionLabel>
                {dangers.map(i => (
                  <AnalysisCard key={i.key} sev="danger" title={`${i.a.name} + ${i.b.name}`} text={i.text} />
                ))}
              </>
            )}

            {/* Warnings */}
            {warns.length > 0 && (
              <>
                <SectionLabel>Caution — Timing or Dose Matters</SectionLabel>
                {warns.map(i => (
                  <AnalysisCard key={i.key} sev="warn" title={`${i.a.name} + ${i.b.name}`} text={i.text} />
                ))}
              </>
            )}

            {/* Synergies */}
            {oks.length > 0 && (
              <>
                <SectionLabel>Synergistic Pairings</SectionLabel>
                {oks.map(i => (
                  <AnalysisCard key={i.key} sev="ok" title={`${i.a.name} + ${i.b.name}`} text={i.text} />
                ))}
              </>
            )}

            {/* All clear */}
            {ulFlags.length === 0 && interactions.length === 0 && (
              <AnalysisCard
                sev="ok"
                title="No known interactions detected"
                text={`Your current stack of ${stack.length} supplement${stack.length > 1 ? 's' : ''} has no flagged interactions in our database. Continue monitoring and review any additions.`}
              />
            )}
          </>
        )}

        {/* Disclaimer */}
        <View style={styles.disclaimer}>
          <Text style={styles.disclaimerText}>
            ⚠️ For informational use only. This is not medical advice. Consult a licensed healthcare professional before starting any supplement regimen, especially with SARMs or peptides.
          </Text>
        </View>

        <View style={{ height: Spacing.xxl }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgDeep },
  scroll: { flex: 1 },
  content: { padding: Spacing.xl, paddingBottom: 0 },

  screenTitle: {
    fontSize: 28, fontWeight: '700', color: Colors.white,
    letterSpacing: -0.5, marginBottom: Spacing.xl,
  },

  sarmBanner: {
    flexDirection: 'row', gap: Spacing.md,
    backgroundColor: 'rgba(255,92,122,0.1)',
    borderWidth: 1, borderColor: 'rgba(255,92,122,0.3)',
    borderRadius: Radius.lg, padding: Spacing.md,
    marginBottom: Spacing.lg,
  },
  sarmBannerIcon: { fontSize: 20 },
  sarmBannerBody: { flex: 1 },
  sarmBannerTitle: {
    fontSize: 13, fontWeight: '600', color: Colors.danger, marginBottom: 4,
  },
  sarmBannerText: { fontSize: 12, color: Colors.silver, lineHeight: 18 },

  disclaimer: {
    backgroundColor: 'rgba(155,109,255,0.06)',
    borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.lg, padding: Spacing.md,
    marginTop: Spacing.lg,
  },
  disclaimerText: { fontSize: 11, color: Colors.silverDim, lineHeight: 17 },
});
