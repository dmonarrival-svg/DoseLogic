// src/screens/AnalysisScreen.tsx
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radius } from '../theme';
import { StackItem } from '../hooks/useStack';
import { useAnalysis } from '../hooks/useAnalysis';
import { SectionLabel, AnalysisCard, EmptyState, SarmBanner, Disclaimer } from '../components';

interface Props { stack: StackItem[]; }

export default function AnalysisScreen({ stack }: Props) {
  const { interactions, ulBreaches, sarmCount, dangerCount, warnCount } = useAnalysis(stack);

  const dangers = interactions.filter(i => i.sev === 'danger');
  const warns = interactions.filter(i => i.sev === 'warn');
  const infos = interactions.filter(i => i.sev === 'ok');

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Interaction Analysis</Text>
          <Text style={styles.subtitle}>
            {stack.length === 0
              ? 'Add supplements to your stack first'
              : `${stack.length} supplement${stack.length > 1 ? 's' : ''} · ${dangerCount} risk${dangerCount !== 1 ? 's' : ''} · ${warnCount} caution${warnCount !== 1 ? 's' : ''}`}
          </Text>
        </View>

        {stack.length === 0 ? (
          <EmptyState icon="🔬" text={"Add supplements to see detailed\ninteraction and risk analysis"} />
        ) : (
          <>
            {/* SARM Banner */}
            {sarmCount > 0 && <SarmBanner count={sarmCount} />}

            {/* UL Breaches */}
            {ulBreaches.length > 0 && (
              <View style={styles.section}>
                <SectionLabel>Upper limit exceeded</SectionLabel>
                {ulBreaches.map(s => (
                  <AnalysisCard
                    key={s.id}
                    sev="danger"
                    title={`⬆ ${s.name} — dose exceeds UL`}
                    body={`Your dose (${s.dose} ${s.unit}) exceeds the tolerable upper intake level of ${s.ul} ${s.unit}. Risk of toxicity increases above this threshold.`}
                  />
                ))}
              </View>
            )}

            {/* Dangers */}
            {dangers.length > 0 && (
              <View style={styles.section}>
                <SectionLabel>High risk interactions</SectionLabel>
                {dangers.map(i => (
                  <AnalysisCard key={i.key} sev="danger" title={`${i.a.name} + ${i.b.name}`} body={i.text} />
                ))}
              </View>
            )}

            {/* Warnings */}
            {warns.length > 0 && (
              <View style={styles.section}>
                <SectionLabel>Cautions</SectionLabel>
                {warns.map(i => (
                  <AnalysisCard key={i.key} sev="warn" title={`${i.a.name} + ${i.b.name}`} body={i.text} />
                ))}
              </View>
            )}

            {/* Synergies */}
            {infos.length > 0 && (
              <View style={styles.section}>
                <SectionLabel>Synergies</SectionLabel>
                {infos.map(i => (
                  <AnalysisCard key={i.key} sev="ok" title={`${i.a.name} + ${i.b.name}`} body={i.text} />
                ))}
              </View>
            )}

            {/* All clear */}
            {interactions.length === 0 && ulBreaches.length === 0 && sarmCount === 0 && (
              <AnalysisCard
                sev="ok"
                title="No known interactions detected"
                body={`Your stack of ${stack.length} supplement${stack.length > 1 ? 's' : ''} has no flagged interactions in our database. Continue monitoring and review any new additions.`}
              />
            )}
          </>
        )}

        <Disclaimer />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgDeep },
  scroll: { flex: 1 },
  content: { padding: Spacing.xl, paddingBottom: 40 },
  header: { marginBottom: Spacing.lg },
  title: { fontSize: 22, fontWeight: '700', color: Colors.white, marginBottom: 4 },
  subtitle: { fontSize: 13, color: Colors.silverDim },
  section: { marginBottom: Spacing.sm },
});
