import React, { useState, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList,
  ScrollView, StyleSheet, SafeAreaView, StatusBar,
} from 'react-native';
import { useStack } from '../context/StackContext';
import { SUPPLEMENTS, CATEGORIES } from '../data/supplements';
import {
  CategoryBadge, SectionLabel, MetricCard, StackCard, EmptyState,
} from '../components';
import { Colors, Spacing, Radius, Typography } from '../theme';

export default function StackScreen() {
  const { stack, addItem, removeItem, updateDose, getSummary } = useStack();
  const [query, setQuery] = useState('');
  const [activeCat, setActiveCat] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);

  const filtered = SUPPLEMENTS.filter(s => {
    const mc = !activeCat || s.cat === activeCat;
    const mq = !query || s.name.toLowerCase().includes(query.toLowerCase());
    return mc && mq && !stack.find(x => x.id === s.id);
  }).slice(0, 12);

  const handleSearch = useCallback((text) => {
    setQuery(text);
    setShowDropdown(text.length > 0 || activeCat !== '');
  }, [activeCat]);

  const handleCat = useCallback((cat) => {
    setActiveCat(cat);
    setShowDropdown(cat !== '' || query.length > 0);
  }, [query]);

  const handleAdd = useCallback((id) => {
    addItem(id);
    setQuery('');
    setShowDropdown(false);
  }, [addItem]);

  const summary = getSummary();

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bgDeep} />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.logoText}>
              Dose<Text style={styles.logoAccent}>Logic</Text>
            </Text>
            <Text style={styles.tagline}>Stack analyzer & interaction checker</Text>
          </View>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>DL</Text>
          </View>
        </View>

        {/* Search */}
        <View style={styles.searchBox}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput
            style={styles.searchInput}
            placeholder="Search supplements, SARMs, peptides…"
            placeholderTextColor={Colors.silverDim}
            value={query}
            onChangeText={handleSearch}
            onFocus={() => setShowDropdown(true)}
            autoCapitalize="none"
            autoCorrect={false}
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={() => { setQuery(''); setShowDropdown(false); }}>
              <Text style={styles.clearBtn}>×</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Category pills */}
        <ScrollView
          horizontal showsHorizontalScrollIndicator={false}
          style={styles.catScroll} contentContainerStyle={styles.catContent}
        >
          {CATEGORIES.map(c => (
            <TouchableOpacity
              key={c.id}
              style={[styles.catPill, activeCat === c.id && styles.catPillActive]}
              onPress={() => handleCat(c.id)}
            >
              <Text style={[styles.catPillText, activeCat === c.id && styles.catPillTextActive]}>
                {c.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Dropdown */}
        {showDropdown && filtered.length > 0 && (
          <View style={styles.dropdown}>
            {filtered.map((s, i) => (
              <TouchableOpacity
                key={s.id}
                style={[styles.dropItem, i < filtered.length - 1 && styles.dropItemBorder]}
                onPress={() => handleAdd(s.id)}
                activeOpacity={0.7}
              >
                <View style={styles.dropLeft}>
                  <Text style={styles.dropName}>
                    {s.name}
                    {s.sarmFlag ? '  🔴' : ''}
                    {s.peptideFlag ? '  🟣' : ''}
                  </Text>
                  <Text style={styles.dropSub}>
                    {s.defaultDose} {s.unit} default{s.ul ? ` · UL: ${s.ul} ${s.unit}` : ''}
                  </Text>
                </View>
                <CategoryBadge cat={s.cat} />
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Stack list */}
        <SectionLabel>Current Stack</SectionLabel>
        {stack.length === 0 ? (
          <EmptyState emoji="💊" text={'Search above to add supplements,\nSARMs, or peptides to your stack'} />
        ) : (
          stack.map(item => (
            <StackCard
              key={item.id}
              item={item}
              onRemove={removeItem}
              onDoseChange={updateDose}
            />
          ))
        )}

        {/* Summary */}
        <SectionLabel style={{ marginTop: Spacing.xl }}>Summary</SectionLabel>
        <View style={styles.summaryGrid}>
          <MetricCard value={summary.total} label="Items" />
          <MetricCard
            value={summary.overlaps}
            label="Overlaps"
            valueColor={summary.overlaps > 0 ? Colors.warn : undefined}
          />
          <MetricCard
            value={summary.risks}
            label="Risks"
            valueColor={summary.risks > 0 ? Colors.danger : Colors.ok}
          />
        </View>

        <View style={{ height: Spacing.xxl }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgDeep },
  scroll: { flex: 1 },
  content: { padding: Spacing.xl, paddingBottom: 0 },

  header: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: Spacing.lg,
  },
  logoText: { fontSize: 28, fontWeight: '700', color: Colors.white, letterSpacing: -0.5 },
  logoAccent: { color: Colors.purpleBright },
  tagline: { fontSize: 12, color: Colors.silverDim, marginTop: 2 },
  avatar: {
    width: 42, height: 42, borderRadius: 21,
    backgroundColor: Colors.purpleMid,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarText: { fontSize: 14, fontWeight: '700', color: Colors.white },

  searchBox: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.lg, paddingHorizontal: Spacing.md, paddingVertical: 12,
    marginBottom: Spacing.sm,
  },
  searchIcon: { fontSize: 14 },
  searchInput: {
    flex: 1, fontSize: 15, color: Colors.white, padding: 0,
  },
  clearBtn: { fontSize: 20, color: Colors.silverDim, paddingHorizontal: 4 },

  catScroll: { marginBottom: Spacing.md },
  catContent: { gap: Spacing.sm, paddingRight: Spacing.xl },
  catPill: {
    paddingHorizontal: 14, paddingVertical: 7,
    borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border,
    backgroundColor: Colors.bgCard,
  },
  catPillActive: {
    backgroundColor: Colors.purpleGlow, borderColor: Colors.purpleBright,
  },
  catPillText: { fontSize: 12, fontWeight: '500', color: Colors.silverDim },
  catPillTextActive: { color: Colors.purpleSoft },

  dropdown: {
    backgroundColor: Colors.bgElevated, borderWidth: 1, borderColor: Colors.borderBright,
    borderRadius: Radius.lg, marginBottom: Spacing.md, overflow: 'hidden',
  },
  dropItem: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: 12,
  },
  dropItemBorder: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  dropLeft: { flex: 1, marginRight: Spacing.sm },
  dropName: { fontSize: 14, fontWeight: '500', color: Colors.white },
  dropSub: { fontSize: 11, color: Colors.silverDim, marginTop: 2 },

  summaryGrid: {
    flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.lg,
  },
});
