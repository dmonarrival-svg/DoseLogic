// src/screens/StackScreen.tsx
import React, { useState, useMemo } from 'react';
import {
  View, Text, TextInput, ScrollView, TouchableOpacity,
  StyleSheet, FlatList, KeyboardAvoidingView, Platform,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Radius, Spacing } from '../theme';
import { SUPPLEMENTS, Category, Supplement } from '../data/supplements';
import { StackItem } from '../hooks/useStack';
import { useAnalysis } from '../hooks/useAnalysis';
import {
  CategoryBadge, CatDot, SectionLabel, MetricCard,
  EmptyState, Disclaimer,
} from '../components';

const CATEGORIES: { label: string; value: Category | '' }[] = [
  { label: 'All', value: '' },
  { label: 'Vitamins', value: 'vitamin' },
  { label: 'Minerals', value: 'mineral' },
  { label: 'Weight Loss', value: 'weight' },
  { label: 'Gym', value: 'gym' },
  { label: 'Amino', value: 'amino' },
  { label: 'Nootropics', value: 'nootropic' },
  { label: 'SARMs', value: 'sarm' },
  { label: 'Peptides', value: 'peptide' },
];

interface Props {
  stack: StackItem[];
  addItem: (s: Supplement) => void;
  removeItem: (id: string) => void;
  updateDose: (id: string, dose: number) => void;
  clearStack: () => void;
}

export default function StackScreen({ stack, addItem, removeItem, updateDose, clearStack }: Props) {
  const [query, setQuery] = useState('');
  const [activeCat, setActiveCat] = useState<Category | ''>('');
  const [showDropdown, setShowDropdown] = useState(false);

  const { dangerCount, warnCount, interactions } = useAnalysis(stack);

  const searchResults = useMemo(() => {
    if (!query && !activeCat) return [];
    return SUPPLEMENTS.filter(s => {
      const matchCat = !activeCat || s.cat === activeCat;
      const matchQ = !query || s.name.toLowerCase().includes(query.toLowerCase());
      const notInStack = !stack.find(x => x.id === s.id);
      return matchCat && matchQ && notInStack;
    }).slice(0, 12);
  }, [query, activeCat, stack]);

  function handleAdd(s: Supplement) {
    addItem(s);
    setQuery('');
    setShowDropdown(false);
  }

  function handleClearStack() {
    Alert.alert('Clear Stack', 'Remove all supplements from your stack?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: clearStack },
    ]);
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={90}
      >
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View style={styles.header}>
            <View>
              <Text style={styles.logoText}>
                Dose<Text style={styles.logoPurple}>Logic</Text>
              </Text>
              <Text style={styles.logoSub}>Stack analyzer &amp; interaction checker</Text>
            </View>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>DL</Text>
            </View>
          </View>

          {/* Search */}
          <View style={styles.searchBox}>
            <Text style={styles.searchIcon}>🔍</Text>
            <TextInput
              style={styles.searchInput}
              placeholder="Search supplements, SARMs, peptides…"
              placeholderTextColor={Colors.silverDim}
              value={query}
              onChangeText={t => { setQuery(t); setShowDropdown(true); }}
              onFocus={() => setShowDropdown(true)}
              autoCorrect={false}
              autoCapitalize="none"
              returnKeyType="search"
            />
            {query.length > 0 && (
              <TouchableOpacity onPress={() => { setQuery(''); setShowDropdown(false); }}>
                <Text style={styles.clearBtn}>×</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Category Pills */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.catScroll}
            contentContainerStyle={styles.catContent}
          >
            {CATEGORIES.map(c => (
              <TouchableOpacity
                key={c.value}
                style={[styles.catPill, activeCat === c.value && styles.catPillActive]}
                onPress={() => {
                  setActiveCat(c.value as Category | '');
                  setShowDropdown(true);
                }}
              >
                <Text style={[styles.catLabel, activeCat === c.value && styles.catLabelActive]}>
                  {c.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Dropdown */}
          {showDropdown && searchResults.length > 0 && (
            <View style={styles.dropdown}>
              {searchResults.map((s, idx) => (
                <TouchableOpacity
                  key={s.id}
                  style={[styles.dropdownItem, idx < searchResults.length - 1 && styles.dropdownDivider]}
                  onPress={() => handleAdd(s)}
                  activeOpacity={0.7}
                >
                  <View style={styles.diLeft}>
                    <View style={styles.diNameRow}>
                      <Text style={styles.diName}>{s.name}</Text>
                      {s.sarmFlag && <Text style={styles.sarmTag}> SARM</Text>}
                      {s.peptideFlag && <Text style={styles.peptideTag}> Peptide</Text>}
                    </View>
                    <Text style={styles.diSub}>{s.defaultDose} {s.unit} default{s.ul ? ` · UL: ${s.ul} ${s.unit}` : ''}</Text>
                  </View>
                  <CategoryBadge cat={s.cat} />
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Stack */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <SectionLabel>Current stack</SectionLabel>
              {stack.length > 0 && (
                <TouchableOpacity onPress={handleClearStack}>
                  <Text style={styles.clearStackBtn}>Clear all</Text>
                </TouchableOpacity>
              )}
            </View>

            {stack.length === 0 ? (
              <EmptyState icon="💊" text={"Search above to add supplements,\nSARMs, or peptides to your stack"} />
            ) : (
              stack.map(item => (
                <StackCard
                  key={item.id}
                  item={item}
                  onRemove={removeItem}
                  onDoseChange={updateDose}
                />
              ))
            )}
          </View>

          {/* Summary */}
          {stack.length > 0 && (
            <View style={styles.section}>
              <SectionLabel>Summary</SectionLabel>
              <View style={styles.metricsRow}>
                <MetricCard value={stack.length} label="Items" />
                <View style={{ width: 10 }} />
                <MetricCard
                  value={interactions.length}
                  label="Overlaps"
                  valueColor={interactions.length > 0 ? Colors.warn : undefined}
                />
                <View style={{ width: 10 }} />
                <MetricCard
                  value={dangerCount}
                  label="Risks"
                  valueColor={dangerCount > 0 ? Colors.danger : Colors.ok}
                />
              </View>
            </View>
          )}

          <Disclaimer />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ─── STACK CARD ─────────────────────────────────────────────────────

function StackCard({
  item, onRemove, onDoseChange,
}: { item: StackItem; onRemove: (id: string) => void; onDoseChange: (id: string, dose: number) => void }) {
  const [doseText, setDoseText] = useState(String(item.dose));
  const isOverUL = item.ul !== null && item.dose > item.ul!;

  return (
    <View style={[styles.stackCard, isOverUL && styles.stackCardWarn]}>
      <CatDot cat={item.cat} size={10} />
      <View style={styles.scInfo}>
        <Text style={styles.scName} numberOfLines={1}>{item.name}</Text>
        <Text style={styles.scMeta}>
          {item.cat}{item.ul ? ` · UL ${item.ul} ${item.unit}` : ''}
          {item.sarmFlag ? ' · SARM' : ''}{item.peptideFlag ? ' · Peptide' : ''}
        </Text>
      </View>
      <View style={styles.scDose}>
        <TextInput
          style={[styles.doseInput, isOverUL && styles.doseInputWarn]}
          value={doseText}
          onChangeText={setDoseText}
          onBlur={() => {
            const n = parseFloat(doseText);
            if (!isNaN(n) && n > 0) onDoseChange(item.id, n);
            else setDoseText(String(item.dose));
          }}
          keyboardType="numeric"
          selectTextOnFocus
        />
        <Text style={styles.doseUnit}>{item.unit}</Text>
      </View>
      <TouchableOpacity style={styles.removeBtn} onPress={() => onRemove(item.id)}>
        <Text style={styles.removeBtnText}>×</Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── STYLES ─────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgDeep },
  scroll: { flex: 1 },
  content: { padding: Spacing.xl, paddingBottom: 40 },

  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.lg },
  logoText: { fontSize: 28, fontWeight: '700', color: Colors.white, letterSpacing: -0.5 },
  logoPurple: { color: Colors.purpleBright },
  logoSub: { fontSize: 12, color: Colors.silverDim, marginTop: 2 },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: Colors.purpleMid, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 14, fontWeight: '600', color: Colors.white },

  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, paddingHorizontal: 14, paddingVertical: 12, marginBottom: 10 },
  searchIcon: { fontSize: 14 },
  searchInput: { flex: 1, fontSize: 15, color: Colors.white, padding: 0 },
  clearBtn: { fontSize: 20, color: Colors.silverDim, paddingHorizontal: 4 },

  catScroll: { marginBottom: 10 },
  catContent: { gap: 8, paddingRight: 8 },
  catPill: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: Radius.pill, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.bgCard },
  catPillActive: { backgroundColor: Colors.purpleGlow, borderColor: Colors.purpleBright },
  catLabel: { fontSize: 12, fontWeight: '500', color: Colors.silverDim },
  catLabelActive: { color: Colors.purpleSoft },

  dropdown: { backgroundColor: Colors.bgElevated, borderWidth: 1, borderColor: Colors.borderBright, borderRadius: Radius.md, overflow: 'hidden', marginBottom: 14 },
  dropdownItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12 },
  dropdownDivider: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  diLeft: { flex: 1, marginRight: 10 },
  diNameRow: { flexDirection: 'row', alignItems: 'center' },
  diName: { fontSize: 14, fontWeight: '500', color: Colors.white },
  sarmTag: { fontSize: 10, color: Colors.danger, fontWeight: '600' },
  peptideTag: { fontSize: 10, color: '#DC64FF', fontWeight: '600' },
  diSub: { fontSize: 11, color: Colors.silverDim, marginTop: 2 },

  section: { marginTop: Spacing.lg },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.sm },
  clearStackBtn: { fontSize: 12, color: Colors.danger, fontWeight: '500' },

  stackCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 14, marginBottom: 10 },
  stackCardWarn: { borderColor: Colors.warnBorder },
  scInfo: { flex: 1, minWidth: 0 },
  scName: { fontSize: 14, fontWeight: '600', color: Colors.white },
  scMeta: { fontSize: 11, color: Colors.silverDim, marginTop: 2 },
  scDose: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  doseInput: { width: 60, paddingHorizontal: 8, paddingVertical: 7, backgroundColor: Colors.bgInput, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.sm, fontFamily: 'Courier New', fontSize: 13, color: Colors.purpleSoft, textAlign: 'center' },
  doseInputWarn: { borderColor: Colors.warnBorder, color: Colors.warn },
  doseUnit: { fontSize: 11, color: Colors.silverDim },
  removeBtn: { width: 28, height: 28, borderRadius: 14, backgroundColor: Colors.dangerBg, alignItems: 'center', justifyContent: 'center' },
  removeBtnText: { fontSize: 18, color: Colors.danger, lineHeight: 22 },

  metricsRow: { flexDirection: 'row' },
});
