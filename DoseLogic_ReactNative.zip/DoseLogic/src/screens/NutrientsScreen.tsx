// src/screens/NutrientsScreen.tsx
import React, { useMemo } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radius } from '../theme';
import { NUTRIENT_REFS } from '../data/supplements';
import { StackItem } from '../hooks/useStack';
import { SectionLabel, NutrientBar, EmptyState, Disclaimer } from '../components';

interface Props { stack: StackItem[]; }

export default function NutrientsScreen({ stack }: Props) {
  const nutrientTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    stack.forEach(s => {
      if (s.nutrients) {
        Object.entries(s.nutrients).forEach(([k, v]) => {
          totals[k] = (totals[k] || 0) + ((v / s.defaultDose) * s.dose);
        });
      }
    });
    return totals;
  }, [stack]);

  const trackedNutrients = Object.keys(nutrientTotals).filter(k => NUTRIENT_REFS[k]);

  const overLimit = trackedNutrients.filter(k => {
    const ref = NUTRIENT_REFS[k];
    return ref.ul !== null && nutrientTotals[k] > ref.ul!;
  });

  const nearLimit = trackedNutrients.filter(k => {
    const ref = NUTRIENT_REFS[k];
    if (!ref.ul) return false;
    const v = nutrientTotals[k];
    return v <= ref.ul! && v > ref.ul! * 0.8;
  });

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Nutrient Totals</Text>
          <Text style={styles.subtitle}>Cumulative intake vs. tolerable upper limits</Text>
        </View>

        {trackedNutrients.length === 0 ? (
          <EmptyState icon="📊" text={"Add supplements to visualize\ncumulative nutrient intake vs. upper limits"} />
        ) : (
          <>
            {/* Summary chips */}
            <View style={styles.chipsRow}>
              <View style={[styles.chip, { borderColor: Colors.dangerBorder, backgroundColor: Colors.dangerBg }]}>
                <Text style={[styles.chipNum, { color: Colors.danger }]}>{overLimit.length}</Text>
                <Text style={[styles.chipLabel, { color: Colors.danger }]}>Over UL</Text>
              </View>
              <View style={[styles.chip, { borderColor: Colors.warnBorder, backgroundColor: Colors.warnBg }]}>
                <Text style={[styles.chipNum, { color: Colors.warn }]}>{nearLimit.length}</Text>
                <Text style={[styles.chipLabel, { color: Colors.warn }]}>Near UL</Text>
              </View>
              <View style={[styles.chip, { borderColor: Colors.okBorder, backgroundColor: Colors.okBg }]}>
                <Text style={[styles.chipNum, { color: Colors.ok }]}>{trackedNutrients.length}</Text>
                <Text style={[styles.chipLabel, { color: Colors.ok }]}>Tracked</Text>
              </View>
            </View>

            {/* Legend */}
            <View style={styles.legend}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: Colors.purpleBright }]} />
                <Text style={styles.legendLabel}>Normal range</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: Colors.warn }]} />
                <Text style={styles.legendLabel}>Approaching UL (80%+)</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: Colors.danger }]} />
                <Text style={styles.legendLabel}>Exceeds UL</Text>
              </View>
            </View>

            {/* Bars */}
            <View style={styles.section}>
              <SectionLabel>Daily totals</SectionLabel>
              {trackedNutrients.map(k => {
                const ref = NUTRIENT_REFS[k];
                const val = Math.round(nutrientTotals[k] * 10) / 10;
                return (
                  <NutrientBar
                    key={k}
                    label={ref.label}
                    value={val}
                    ul={ref.ul}
                    unit={ref.unit}
                  />
                );
              })}
            </View>

            {/* UL note */}
            <View style={styles.ulNote}>
              <Text style={styles.ulNoteTitle}>About Upper Limits (UL)</Text>
              <Text style={styles.ulNoteBody}>
                The Tolerable Upper Intake Level (UL) is the maximum daily intake unlikely to cause
                adverse health effects in most people. Exceeding the UL does not always mean harm,
                but increases risk. Some nutrients (marked —) have no established UL.
              </Text>
            </View>
          </>
        )}

        <Disclaimer />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgDeep },
  scroll: { flex: 1 },
  content: { padding: Spacing.xl, paddingBottom: 40 },
  header: { marginBottom: Spacing.lg },
  title: { fontSize: 22, fontWeight: '700', color: Colors.white, marginBottom: 4 },
  subtitle: { fontSize: 13, color: Colors.silverDim },
  chipsRow: { flexDirection: 'row', gap: 10, marginBottom: Spacing.md },
  chip: { flex: 1, borderWidth: 1, borderRadius: Radius.md, padding: 12, alignItems: 'center' },
  chipNum: { fontSize: 22, fontWeight: '700' },
  chipLabel: { fontSize: 10, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 2 },
  legend: { backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 12, marginBottom: Spacing.md, gap: 8 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendLabel: { fontSize: 12, color: Colors.silver },
  section: { marginBottom: Spacing.md },
  ulNote: { backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 14, marginTop: Spacing.sm },
  ulNoteTitle: { fontSize: 13, fontWeight: '600', color: Colors.purpleSoft, marginBottom: 6 },
  ulNoteBody: { fontSize: 12, color: Colors.silverDim, lineHeight: 18 },
});
