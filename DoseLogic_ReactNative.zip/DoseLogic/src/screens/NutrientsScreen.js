import React from 'react';
import { View, Text, ScrollView, StyleSheet, SafeAreaView, StatusBar } from 'react-native';
import { useStack } from '../context/StackContext';
import { NutrientBar, SectionLabel, EmptyState } from '../components';
import { Colors, Spacing, Radius } from '../theme';
import { NUTRIENT_REFS } from '../data/supplements';

export default function NutrientsScreen() {
  const { stack, getNutrientTotals } = useStack();
  const totals = getNutrientTotals();
  const keys = Object.keys(totals).filter(k => NUTRIENT_REFS[k]);

  // Separate into over-limit, near-limit, and ok
  const overLimit = keys.filter(k => NUTRIENT_REFS[k].ul && totals[k] > NUTRIENT_REFS[k].ul);
  const nearLimit = keys.filter(k => NUTRIENT_REFS[k].ul && totals[k] > NUTRIENT_REFS[k].ul * 0.8 && totals[k] <= NUTRIENT_REFS[k].ul);
  const safeKeys = keys.filter(k => !NUTRIENT_REFS[k].ul || totals[k] <= NUTRIENT_REFS[k].ul * 0.8);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bgDeep} />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.screenTitle}>Nutrients</Text>

        {stack.length === 0 || keys.length === 0 ? (
          <EmptyState emoji="📊" text="Add supplements to visualize cumulative nutrient intake vs. established upper limits" />
        ) : (
          <>
            {/* Legend */}
            <View style={styles.legend}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: Colors.purpleBright }]} />
                <Text style={styles.legendText}>Safe range</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: Colors.warn }]} />
                <Text style={styles.legendText}>Near upper limit</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: Colors.danger }]} />
                <Text style={styles.legendText}>Exceeds upper limit</Text>
              </View>
            </View>

            {overLimit.length > 0 && (
              <>
                <SectionLabel>Exceeds Upper Limit</SectionLabel>
                {overLimit.map(k => (
                  <NutrientBar key={k} label={NUTRIENT_REFS[k].label} value={totals[k]} ul={NUTRIENT_REFS[k].ul} unit={NUTRIENT_REFS[k].unit} />
                ))}
              </>
            )}

            {nearLimit.length > 0 && (
              <>
                <SectionLabel>Approaching Upper Limit</SectionLabel>
                {nearLimit.map(k => (
                  <NutrientBar key={k} label={NUTRIENT_REFS[k].label} value={totals[k]} ul={NUTRIENT_REFS[k].ul} unit={NUTRIENT_REFS[k].unit} />
                ))}
              </>
            )}

            {safeKeys.length > 0 && (
              <>
                <SectionLabel>Within Safe Range</SectionLabel>
                {safeKeys.map(k => (
                  <NutrientBar key={k} label={NUTRIENT_REFS[k].label} value={totals[k]} ul={NUTRIENT_REFS[k].ul} unit={NUTRIENT_REFS[k].unit} />
                ))}
              </>
            )}

            {/* Note about items without tracked nutrients */}
            {stack.length > keys.length && (
              <View style={styles.note}>
                <Text style={styles.noteText}>
                  {stack.length - keys.length} item{stack.length - keys.length > 1 ? 's' : ''} in your stack (SARMs, peptides, some supplements) don't have tracked micronutrients and won't appear here.
                </Text>
              </View>
            )}
          </>
        )}

        <View style={{ height: Spacing.xxl }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgDeep },
  scroll: { flex: 1 },
  content: { padding: Spacing.xl, paddingBottom: 0 },

  screenTitle: {
    fontSize: 28, fontWeight: '700', color: Colors.white,
    letterSpacing: -0.5, marginBottom: Spacing.xl,
  },

  legend: {
    flexDirection: 'row', gap: Spacing.lg,
    backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.lg, padding: Spacing.md, marginBottom: Spacing.lg,
  },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendText: { fontSize: 11, color: Colors.silverDim },

  note: {
    backgroundColor: 'rgba(155,109,255,0.06)',
    borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.lg, padding: Spacing.md, marginTop: Spacing.md,
  },
  noteText: { fontSize: 12, color: Colors.silverDim, lineHeight: 18 },
});
