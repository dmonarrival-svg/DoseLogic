import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';
import { Colors, Radius, Spacing, Typography } from '../theme';

// ── Category badge ────────────────────────────────────────────────────────────
const CAT_BADGE_COLORS = {
  vitamin:   { bg: 'rgba(79,212,160,0.15)',   text: '#4FD4A0' },
  mineral:   { bg: 'rgba(155,109,255,0.15)',  text: '#C4A8FF' },
  weight:    { bg: 'rgba(255,170,60,0.15)',   text: '#FFAA3C' },
  gym:       { bg: 'rgba(100,160,255,0.15)',  text: '#64A0FF' },
  amino:     { bg: 'rgba(200,200,212,0.15)',  text: '#C8C8D4' },
  nootropic: { bg: 'rgba(255,200,100,0.15)',  text: '#FFC864' },
  sarm:      { bg: 'rgba(255,92,122,0.2)',    text: '#FF5C7A' },
  peptide:   { bg: 'rgba(220,100,255,0.15)',  text: '#DC64FF' },
};

export const CAT_DOT_COLORS = {
  vitamin: '#4FD4A0', mineral: '#9B6DFF', weight: '#FFAA3C',
  gym: '#64A0FF', amino: '#C8C8D4', nootropic: '#FFC864',
  sarm: '#FF5C7A', peptide: '#DC64FF',
};

export function CategoryBadge({ cat }) {
  const c = CAT_BADGE_COLORS[cat] || { bg: Colors.bgElevated, text: Colors.silver };
  return (
    <View style={[styles.badge, { backgroundColor: c.bg }]}>
      <Text style={[styles.badgeText, { color: c.text }]}>{cat}</Text>
    </View>
  );
}

// ── Section label ─────────────────────────────────────────────────────────────
export function SectionLabel({ children }) {
  return <Text style={styles.sectionLabel}>{children}</Text>;
}

// ── Metric card ───────────────────────────────────────────────────────────────
export function MetricCard({ value, label, valueColor }) {
  return (
    <View style={styles.metricCard}>
      <Text style={[styles.metricNum, valueColor ? { color: valueColor } : {}]}>
        {value}
      </Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

// ── Stack item card ───────────────────────────────────────────────────────────
export function StackCard({ item, onRemove, onDoseChange }) {
  const dotColor = CAT_DOT_COLORS[item.cat] || Colors.silver;
  return (
    <View style={styles.stackCard}>
      <View style={[styles.dot, { backgroundColor: dotColor }]} />
      <View style={styles.stackInfo}>
        <Text style={styles.stackName} numberOfLines={1}>{item.name}</Text>
        <Text style={styles.stackMeta}>
          {item.cat}
          {item.ul ? ` · UL ${item.ul} ${item.unit}` : ''}
          {item.sarmFlag ? ' · SARM' : ''}
          {item.peptideFlag ? ' · Peptide' : ''}
        </Text>
      </View>
      <View style={styles.doseRow}>
        <TextInput
          style={styles.doseInput}
          value={String(item.dose)}
          onChangeText={v => onDoseChange(item.id, v)}
          keyboardType="decimal-pad"
          selectTextOnFocus
        />
        <Text style={styles.doseUnit}>{item.unit}</Text>
      </View>
      <TouchableOpacity style={styles.removeBtn} onPress={() => onRemove(item.id)}>
        <Text style={styles.removeIcon}>×</Text>
      </TouchableOpacity>
    </View>
  );
}

// ── Analysis card ─────────────────────────────────────────────────────────────
const SEV_COLORS = {
  ok:     { bg: 'rgba(79,212,160,0.10)',   border: '#4FD4A0',  title: '#4FD4A0',  body: 'rgba(79,212,160,0.85)'  },
  warn:   { bg: 'rgba(255,170,60,0.10)',   border: '#FFAA3C',  title: '#FFAA3C',  body: 'rgba(255,170,60,0.85)'  },
  danger: { bg: 'rgba(255,92,122,0.10)',   border: '#FF5C7A',  title: '#FF5C7A',  body: 'rgba(255,92,122,0.85)'  },
};

export function AnalysisCard({ sev, title, text }) {
  const c = SEV_COLORS[sev] || SEV_COLORS.warn;
  return (
    <View style={[styles.analysisCard, { backgroundColor: c.bg, borderLeftColor: c.border }]}>
      <Text style={[styles.analysisTitle, { color: c.title }]}>{title}</Text>
      <Text style={[styles.analysisBody, { color: Colors.silver }]}>{text}</Text>
    </View>
  );
}

// ── Nutrient bar ──────────────────────────────────────────────────────────────
export function NutrientBar({ label, value, ul, unit }) {
  const pct = ul ? Math.min((value / ul) * 100, 105) : 50;
  const cls = !ul ? 'ok' : value > ul ? 'danger' : value > ul * 0.8 ? 'warn' : 'ok';
  const fillColor = cls === 'ok' ? Colors.purpleBright : cls === 'warn' ? Colors.warn : Colors.danger;
  const display = ul ? `${Math.round(value * 10) / 10}/${ul} ${unit}` : `${Math.round(value * 10) / 10} ${unit}`;
  return (
    <View style={styles.barRow}>
      <Text style={styles.barLabel} numberOfLines={1}>{label}</Text>
      <View style={styles.barTrack}>
        <View style={[styles.barFill, { width: `${pct.toFixed(1)}%`, backgroundColor: fillColor }]} />
      </View>
      <Text style={styles.barValue}>{display}</Text>
    </View>
  );
}

// ── Empty state ───────────────────────────────────────────────────────────────
export function EmptyState({ emoji, text }) {
  return (
    <View style={styles.emptyState}>
      <Text style={styles.emptyEmoji}>{emoji}</Text>
      <Text style={styles.emptyText}>{text}</Text>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: Radius.full,
  },
  badgeText: { fontSize: 10, fontWeight: '600' },

  sectionLabel: {
    fontSize: 11, fontWeight: '600', color: Colors.silverDim,
    textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: Spacing.sm,
  },

  metricCard: {
    flex: 1, backgroundColor: Colors.bgCard,
    borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.lg, padding: Spacing.md,
  },
  metricNum: {
    fontSize: 28, fontWeight: '700', color: Colors.white, lineHeight: 32,
  },
  metricLabel: {
    fontSize: 10, fontWeight: '500', color: Colors.silverDim,
    textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 4,
  },

  stackCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.bgCard,
    borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.lg, padding: Spacing.md,
    marginBottom: Spacing.sm, gap: Spacing.sm,
  },
  dot: { width: 10, height: 10, borderRadius: 5 },
  stackInfo: { flex: 1, minWidth: 0 },
  stackName: { fontSize: 14, fontWeight: '600', color: Colors.white },
  stackMeta: { fontSize: 11, color: Colors.silverDim, marginTop: 2 },
  doseRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  doseInput: {
    width: 58, paddingVertical: 6, paddingHorizontal: 8,
    backgroundColor: Colors.bgInput, borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.md, fontFamily: 'Courier', fontSize: 13,
    color: Colors.purpleSoft, textAlign: 'center',
  },
  doseUnit: { fontSize: 11, color: Colors.silverDim, minWidth: 28 },
  removeBtn: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(255,92,122,0.1)',
    alignItems: 'center', justifyContent: 'center',
  },
  removeIcon: { fontSize: 18, color: Colors.danger, lineHeight: 22 },

  analysisCard: {
    borderLeftWidth: 3, borderRadius: Radius.md,
    padding: Spacing.md, marginBottom: Spacing.sm,
  },
  analysisTitle: { fontSize: 13, fontWeight: '600', marginBottom: 4 },
  analysisBody: { fontSize: 12, lineHeight: 18 },

  barRow: {
    flexDirection: 'row', alignItems: 'center',
    gap: Spacing.sm, marginBottom: Spacing.md,
  },
  barLabel: { fontSize: 12, fontWeight: '500', color: Colors.silver, width: 96 },
  barTrack: {
    flex: 1, height: 6,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderRadius: 3, overflow: 'hidden',
  },
  barFill: { height: '100%', borderRadius: 3 },
  barValue: {
    fontFamily: 'Courier', fontSize: 10,
    color: Colors.silverDim, width: 80, textAlign: 'right',
  },

  emptyState: {
    backgroundColor: Colors.bgCard,
    borderWidth: 1, borderColor: Colors.border, borderStyle: 'dashed',
    borderRadius: Radius.lg, padding: Spacing.xxl,
    alignItems: 'center',
  },
  emptyEmoji: { fontSize: 32, marginBottom: Spacing.sm, opacity: 0.5 },
  emptyText: {
    fontSize: 13, color: Colors.silverDim,
    textAlign: 'center', lineHeight: 20,
  },
});
