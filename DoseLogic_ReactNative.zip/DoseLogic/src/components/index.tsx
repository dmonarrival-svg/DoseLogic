// src/components/index.tsx
import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ViewStyle, TextStyle,
} from 'react-native';
import { Colors, CatColors, CatBadgeColors, Radius, Spacing } from '../theme';
import { Category, Severity } from '../data/supplements';

// ─── CATEGORY BADGE ─────────────────────────────────────────────────

export function CategoryBadge({ cat }: { cat: Category }) {
  const colors = CatBadgeColors[cat] || { bg: Colors.bgElevated, text: Colors.silver };
  return (
    <View style={[styles.badge, { backgroundColor: colors.bg }]}>
      <Text style={[styles.badgeText, { color: colors.text }]}>{cat}</Text>
    </View>
  );
}

// ─── CAT DOT ────────────────────────────────────────────────────────

export function CatDot({ cat, size = 10 }: { cat: Category; size?: number }) {
  return (
    <View style={{
      width: size, height: size,
      borderRadius: size / 2,
      backgroundColor: CatColors[cat] || Colors.silver,
    }} />
  );
}

// ─── SECTION LABEL ──────────────────────────────────────────────────

export function SectionLabel({ children }: { children: string }) {
  return <Text style={styles.sectionLabel}>{children}</Text>;
}

// ─── METRIC CARD ────────────────────────────────────────────────────

export function MetricCard({
  value, label, valueColor,
}: { value: string | number; label: string; valueColor?: string }) {
  return (
    <View style={styles.metricCard}>
      <Text style={[styles.metricValue, valueColor ? { color: valueColor } : {}]}>
        {value}
      </Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

// ─── ANALYSIS CARD ──────────────────────────────────────────────────

const sevColors: Record<Severity, { bg: string; border: string; titleColor: string }> = {
  ok: { bg: Colors.okBg, border: Colors.ok, titleColor: Colors.ok },
  warn: { bg: Colors.warnBg, border: Colors.warn, titleColor: Colors.warn },
  danger: { bg: Colors.dangerBg, border: Colors.danger, titleColor: Colors.danger },
};

export function AnalysisCard({
  sev, title, body,
}: { sev: Severity; title: string; body: string }) {
  const c = sevColors[sev];
  return (
    <View style={[styles.analysisCard, { backgroundColor: c.bg, borderLeftColor: c.border }]}>
      <Text style={[styles.analysisTitle, { color: c.titleColor }]}>{title}</Text>
      <Text style={styles.analysisBody}>{body}</Text>
    </View>
  );
}

// ─── EMPTY STATE ────────────────────────────────────────────────────

export function EmptyState({ icon, text }: { icon: string; text: string }) {
  return (
    <View style={styles.empty}>
      <Text style={styles.emptyIcon}>{icon}</Text>
      <Text style={styles.emptyText}>{text}</Text>
    </View>
  );
}

// ─── NUTRIENT BAR ───────────────────────────────────────────────────

export function NutrientBar({
  label, value, ul, unit,
}: { label: string; value: number; ul: number | null; unit: string }) {
  const pct = ul ? Math.min((value / ul) * 100, 105) : 50;
  const cls = !ul ? 'ok' : value > ul ? 'danger' : value > ul * 0.8 ? 'warn' : 'ok';
  const fillColor = cls === 'danger' ? Colors.danger : cls === 'warn' ? Colors.warn : Colors.purpleBright;
  const displayVal = ul ? `${value}/${ul}` : `${value}`;

  return (
    <View style={styles.barRow}>
      <Text style={styles.barLabel} numberOfLines={1}>{label}</Text>
      <View style={styles.barTrack}>
        <View style={[styles.barFill, { width: `${pct}%` as any, backgroundColor: fillColor }]} />
      </View>
      <Text style={styles.barVal}>{displayVal} {unit}</Text>
    </View>
  );
}

// ─── SARM WARNING BANNER ────────────────────────────────────────────

export function SarmBanner({ count }: { count: number }) {
  return (
    <View style={styles.sarmBanner}>
      <Text style={styles.sarmIcon}>⚠️</Text>
      <View style={{ flex: 1 }}>
        <Text style={styles.sarmTitle}>SARMs detected in stack ({count})</Text>
        <Text style={styles.sarmBody}>
          SARMs are not FDA-approved. Risks include hormonal suppression, liver stress, and
          cardiovascular strain. Bloodwork (testosterone, LH, FSH, liver enzymes) is strongly
          recommended. PCT may be required post-cycle.
        </Text>
      </View>
    </View>
  );
}

// ─── DISCLAIMER ─────────────────────────────────────────────────────

export function Disclaimer() {
  return (
    <View style={styles.disclaimer}>
      <Text style={styles.disclaimerText}>
        ⚠️ For informational use only. Not medical advice. Always consult a healthcare
        professional before starting any supplement regimen, especially with SARMs or peptides.
      </Text>
    </View>
  );
}

// ─── STYLES ─────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: Radius.pill,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '600',
    textTransform: 'capitalize',
  },
  sectionLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: Colors.silverDim,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: Spacing.sm,
  },
  metricCard: {
    flex: 1,
    backgroundColor: Colors.bgCard,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    alignItems: 'flex-start',
  },
  metricValue: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.white,
    lineHeight: 32,
  },
  metricLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: Colors.silverDim,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginTop: 4,
  },
  analysisCard: {
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    borderLeftWidth: 3,
  },
  analysisTitle: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 5,
  },
  analysisBody: {
    fontSize: 12,
    color: Colors.silver,
    lineHeight: 19,
  },
  empty: {
    backgroundColor: Colors.bgCard,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    borderStyle: 'dashed',
    paddingVertical: 36,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  emptyIcon: { fontSize: 32, marginBottom: 10, opacity: 0.5 },
  emptyText: {
    fontSize: 13,
    color: Colors.silverDim,
    textAlign: 'center',
    lineHeight: 20,
  },
  barRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 12,
  },
  barLabel: {
    fontSize: 12,
    color: Colors.silver,
    fontWeight: '500',
    width: 90,
  },
  barTrack: {
    flex: 1,
    height: 6,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    borderRadius: 3,
  },
  barVal: {
    fontFamily: 'Courier New',
    fontSize: 10,
    color: Colors.silverDim,
    width: 80,
    textAlign: 'right',
  },
  sarmBanner: {
    flexDirection: 'row',
    gap: 12,
    backgroundColor: Colors.dangerBg,
    borderWidth: 1,
    borderColor: Colors.dangerBorder,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    alignItems: 'flex-start',
  },
  sarmIcon: { fontSize: 20 },
  sarmTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.danger,
    marginBottom: 4,
  },
  sarmBody: {
    fontSize: 12,
    color: Colors.silver,
    lineHeight: 18,
  },
  disclaimer: {
    backgroundColor: 'rgba(155,109,255,0.06)',
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginTop: Spacing.lg,
    marginBottom: Spacing.xxl,
  },
  disclaimerText: {
    fontSize: 11,
    color: Colors.silverDim,
    lineHeight: 17,
  },
});
