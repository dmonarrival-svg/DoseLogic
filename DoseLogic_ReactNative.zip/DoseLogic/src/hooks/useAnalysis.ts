// src/hooks/useAnalysis.ts
import { useMemo } from 'react';
import { INTERACTIONS, InteractionRecord, Severity } from '../data/supplements';
import { StackItem } from './useStack';

export interface InteractionResult {
  key: string;
  a: StackItem;
  b: StackItem;
  sev: Severity;
  text: string;
}

export interface AnalysisResult {
  interactions: InteractionResult[];
  ulBreaches: StackItem[];
  sarmCount: number;
  peptideCount: number;
  dangerCount: number;
  warnCount: number;
  totalFlags: number;
}

function getKey(a: string, b: string) {
  return [a, b].sort().join('+');
}

export function useAnalysis(stack: StackItem[]): AnalysisResult {
  return useMemo(() => {
    const interactions: InteractionResult[] = [];

    for (let i = 0; i < stack.length; i++) {
      for (let j = i + 1; j < stack.length; j++) {
        const k = getKey(stack[i].id, stack[j].id);
        const record: InteractionRecord | undefined = INTERACTIONS[k];

        if (record) {
          interactions.push({ key: k, a: stack[i], b: stack[j], ...record });
        } else {
          // Cross-check interaction lists for unlisted pairs
          const aCrossesB = (stack[i].interactions || []).includes(stack[j].id);
          const bCrossesA = (stack[j].interactions || []).includes(stack[i].id);
          if (aCrossesB || bCrossesA) {
            interactions.push({
              key: k,
              a: stack[i],
              b: stack[j],
              sev: 'warn',
              text: `${stack[i].name} and ${stack[j].name} share interaction pathways. Review combined use carefully.`,
            });
          }
        }
      }
    }

    const ulBreaches = stack.filter(s => s.ul !== null && s.dose > s.ul!);
    const sarmCount = stack.filter(s => s.sarmFlag).length;
    const peptideCount = stack.filter(s => s.peptideFlag).length;
    const dangerCount = interactions.filter(i => i.sev === 'danger').length + ulBreaches.length;
    const warnCount = interactions.filter(i => i.sev === 'warn').length;

    return {
      interactions,
      ulBreaches,
      sarmCount,
      peptideCount,
      dangerCount,
      warnCount,
      totalFlags: dangerCount + warnCount,
    };
  }, [stack]);
}
