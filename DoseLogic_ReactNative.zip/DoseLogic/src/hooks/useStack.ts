// src/hooks/useStack.ts
import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Supplement } from '../data/supplements';

export interface StackItem extends Supplement {
  dose: number;
  addedAt: number;
}

const STORAGE_KEY = '@doselogic_stack';

export function useStack() {
  const [stack, setStack] = useState<StackItem[]>([]);
  const [loaded, setLoaded] = useState(false);

  // Load stack from storage on mount
  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then(json => {
      if (json) {
        try { setStack(JSON.parse(json)); } catch {}
      }
      setLoaded(true);
    });
  }, []);

  // Persist whenever stack changes
  useEffect(() => {
    if (loaded) {
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(stack));
    }
  }, [stack, loaded]);

  const addItem = useCallback((supp: Supplement) => {
    setStack(prev => {
      if (prev.find(s => s.id === supp.id)) return prev;
      return [...prev, { ...supp, dose: supp.defaultDose, addedAt: Date.now() }];
    });
  }, []);

  const removeItem = useCallback((id: string) => {
    setStack(prev => prev.filter(s => s.id !== id));
  }, []);

  const updateDose = useCallback((id: string, dose: number) => {
    setStack(prev => prev.map(s => s.id === id ? { ...s, dose } : s));
  }, []);

  const clearStack = useCallback(() => setStack([]), []);

  return { stack, addItem, removeItem, updateDose, clearStack, loaded };
}
