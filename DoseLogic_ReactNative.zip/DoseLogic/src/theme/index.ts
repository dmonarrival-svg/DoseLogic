// src/theme/index.ts

export const Colors = {
  bgDeep: '#0D0818',
  bgCard: '#16102A',
  bgElevated: '#1E1640',
  bgInput: '#120E22',
  purpleBright: '#9B6DFF',
  purpleMid: '#7C4FD4',
  purpleSoft: '#C4A8FF',
  purpleGlow: 'rgba(155,109,255,0.18)',
  silver: '#C8C8D4',
  silverDim: '#8A8A9C',
  silverBright: '#E8E8F0',
  white: '#FFFFFF',
  danger: '#FF5C7A',
  dangerBg: 'rgba(255,92,122,0.12)',
  dangerBorder: 'rgba(255,92,122,0.35)',
  warn: '#FFAA3C',
  warnBg: 'rgba(255,170,60,0.12)',
  warnBorder: 'rgba(255,170,60,0.35)',
  ok: '#4FD4A0',
  okBg: 'rgba(79,212,160,0.12)',
  okBorder: 'rgba(79,212,160,0.35)',
  border: 'rgba(155,109,255,0.15)',
  borderBright: 'rgba(155,109,255,0.35)',
};

export const CatColors: Record<string, string> = {
  vitamin: '#4FD4A0',
  mineral: '#9B6DFF',
  weight: '#FFAA3C',
  gym: '#64A0FF',
  amino: '#C8C8D4',
  nootropic: '#FFC864',
  sarm: '#FF5C7A',
  peptide: '#DC64FF',
};

export const CatBadgeColors: Record<string, { bg: string; text: string }> = {
  vitamin: { bg: 'rgba(79,212,160,0.15)', text: '#4FD4A0' },
  mineral: { bg: 'rgba(155,109,255,0.15)', text: '#C4A8FF' },
  weight: { bg: 'rgba(255,170,60,0.15)', text: '#FFAA3C' },
  gym: { bg: 'rgba(100,160,255,0.15)', text: '#64A0FF' },
  amino: { bg: 'rgba(200,200,212,0.15)', text: '#C8C8D4' },
  nootropic: { bg: 'rgba(255,200,100,0.15)', text: '#FFC864' },
  sarm: { bg: 'rgba(255,92,122,0.2)', text: '#FF5C7A' },
  peptide: { bg: 'rgba(220,100,255,0.15)', text: '#DC64FF' },
};

export const Typography = {
  h1: { fontSize: 28, fontWeight: '700' as const, letterSpacing: -0.5 },
  h2: { fontSize: 22, fontWeight: '700' as const },
  h3: { fontSize: 18, fontWeight: '600' as const },
  body: { fontSize: 15, fontWeight: '400' as const, lineHeight: 22 },
  bodySmall: { fontSize: 13, fontWeight: '400' as const, lineHeight: 20 },
  label: { fontSize: 11, fontWeight: '600' as const, letterSpacing: 0.8 },
  mono: { fontFamily: 'Courier New', fontSize: 13 },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const Radius = {
  sm: 10,
  md: 14,
  lg: 18,
  pill: 999,
};
