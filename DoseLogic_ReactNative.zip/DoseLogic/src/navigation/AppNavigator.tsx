// src/navigation/AppNavigator.tsx
import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '../theme';
import StackScreen from '../screens/StackScreen';
import AnalysisScreen from '../screens/AnalysisScreen';
import NutrientsScreen from '../screens/NutrientsScreen';

const Tab = createBottomTabNavigator();

// Simple SVG-free icons using Unicode / styled boxes
function TabIcon({ name, focused }: { name: string; focused: boolean }) {
  const icons: Record<string, string> = {
    Stack: '⊞',
    Analysis: '◎',
    Nutrients: '▲',
  };
  return (
    <Text style={{ fontSize: 20, color: focused ? Colors.purpleBright : Colors.silverDim }}>
      {icons[name] || '•'}
    </Text>
  );
}

export default function AppNavigator({ stack, addItem, removeItem, updateDose, clearStack }: any) {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: Colors.purpleBright,
        tabBarInactiveTintColor: Colors.silverDim,
        tabBarLabelStyle: styles.tabLabel,
        tabBarIcon: ({ focused }) => <TabIcon name={route.name} focused={focused} />,
      })}
    >
      <Tab.Screen name="Stack">
        {() => <StackScreen stack={stack} addItem={addItem} removeItem={removeItem} updateDose={updateDose} clearStack={clearStack} />}
      </Tab.Screen>
      <Tab.Screen name="Analysis">
        {() => <AnalysisScreen stack={stack} />}
      </Tab.Screen>
      <Tab.Screen name="Nutrients">
        {() => <NutrientsScreen stack={stack} />}
      </Tab.Screen>
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: 'rgba(13,8,24,0.97)',
    borderTopColor: Colors.border,
    borderTopWidth: 1,
    paddingTop: 6,
    height: 82,
  },
  tabLabel: {
    fontSize: 11,
    fontWeight: '500',
    marginBottom: 4,
  },
});
