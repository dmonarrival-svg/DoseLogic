# DoseLogic — Developer Handoff Brief

## What Is This?
DoseLogic is an iOS app that helps users track supplement stacks, see total nutrient doses, and check for dangerous interactions. It covers vitamins, minerals, weight-loss supplements, gym enhancers, amino acids, nootropics, SARMs, and peptides.

---

## Project Structure
```
DoseLogic/
├── App.js                          ← Entry point, navigation, tab bar
├── package.json                    ← All dependencies
├── src/
│   ├── theme/index.js              ← Colors, typography, spacing
│   ├── data/supplements.js         ← Full supplement database + interactions
│   ├── context/StackContext.js     ← Global state (user's stack)
│   ├── components/index.js         ← Reusable UI components
│   └── screens/
│       ├── StackScreen.js          ← Tab 1: Add/manage supplements
│       ├── AnalysisScreen.js       ← Tab 2: Interactions & risk flags
│       └── NutrientsScreen.js      ← Tab 3: Nutrient totals vs UL
```

---

## Tech Stack
- **React Native 0.73** (cross-platform iOS/Android)
- **React Navigation** (bottom tabs)
- **React Context API** (state — no Redux needed)
- No backend required. Everything runs on-device.

---

## Design Spec
- **Primary background:** `#0D0818` (deep dark purple)
- **Cards:** `#16102A`
- **Accent:** `#9B6DFF` (bright purple)
- **Danger:** `#FF5C7A` (red-pink)
- **Warning:** `#FFAA3C` (amber)
- **Safe/OK:** `#4FD4A0` (teal-green)
- **Text:** `#FFFFFF` primary, `#8A8A9C` muted

---

## Setup Instructions

### Prerequisites
- Mac computer (required for iOS builds)
- Xcode 15+ installed (free from App Store)
- Node.js 18+ installed (https://nodejs.org)
- CocoaPods installed: `sudo gem install cocoapods`
- Apple Developer account ($99/year) for App Store publishing

### Steps
```bash
# 1. Navigate to the project folder
cd DoseLogic

# 2. Install JS dependencies
npm install

# 3. Install iOS native dependencies
cd ios && pod install && cd ..

# 4. Run on iOS Simulator
npx react-native run-ios

# 5. Run on physical iPhone
npx react-native run-ios --device "Your iPhone Name"
```

---

## Features Implemented
- [x] Supplement search with live dropdown
- [x] Category filter pills (Vitamins, Minerals, Weight Loss, Gym, Amino, Nootropics, SARMs, Peptides)
- [x] 65+ supplements in database
- [x] Custom dose input per supplement
- [x] Interaction detection engine (30+ known interaction pairs)
- [x] Three severity levels: Danger / Caution / Synergistic
- [x] Upper limit (UL) breach detection
- [x] SARM-specific warning banner
- [x] Nutrient totals vs UL progress bars
- [x] Risk badge on Analysis tab
- [x] Dark purple/silver color scheme

---

## What Still Needs To Be Done (Suggested V2 Features)
- [ ] Push notifications for daily dose reminders
- [ ] User accounts / cloud sync (Firebase or Supabase)
- [ ] Export stack as PDF
- [ ] PCT (Post Cycle Therapy) tracker for SARM cycles
- [ ] Supplement detail pages with full research info
- [ ] App Store assets (icon, screenshots)
- [ ] App Store submission

---

## App Store Submission Checklist
1. Create app in App Store Connect (appstoreconnect.apple.com)
2. Set Bundle ID in Xcode to something unique (e.g., `com.yourname.doselogic`)
3. Create app icon (1024×1024px)
4. Create 6.5" and 5.5" screenshots (6 each)
5. Write app description and keywords
6. Submit for Apple review (~1-3 days)

---

## Contact / Questions
All source code was generated for this project. The developer should have everything needed to build and ship. If they have questions about any file, the logic is heavily commented.

**Estimated dev time to production:**
- Setup + build: 2-4 hours
- Testing on device: 2-3 hours  
- App Store submission: 1-2 hours
- **Total: ~1 day of developer time**
