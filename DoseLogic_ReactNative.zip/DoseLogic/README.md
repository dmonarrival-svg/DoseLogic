# DoseLogic — React Native App

## What's in this project

```
DoseLogic/
├── App.tsx                          ← Root entry point
├── package.json                     ← All dependencies
├── tsconfig.json
├── babel.config.js
└── src/
    ├── theme/index.ts               ← All colors, fonts, spacing
    ├── data/supplements.ts          ← Full supplement DB + interaction rules
    ├── hooks/
    │   ├── useStack.ts              ← Stack state + AsyncStorage persistence
    │   └── useAnalysis.ts           ← Interaction detection logic
    ├── components/index.tsx         ← Shared UI components
    ├── navigation/AppNavigator.tsx  ← Bottom tab navigator
    └── screens/
        ├── StackScreen.tsx          ← Main tab: search + stack management
        ├── AnalysisScreen.tsx       ← Interaction & risk analysis
        └── NutrientsScreen.tsx      ← Nutrient totals vs upper limits
```

---

## Prerequisites

Install these once on your Mac (Windows can build Android only):

| Tool | Install |
|------|---------|
| Node.js 18+ | https://nodejs.org |
| Watchman | `brew install watchman` |
| Xcode 15+ | Mac App Store |
| CocoaPods | `sudo gem install cocoapods` |
| Ruby 3.1+ | `brew install ruby` |

---

## Setup (step by step)

### 1. Initialize a new React Native project

Open Terminal and run:

```bash
npx react-native@0.73 init DoseLogic --template react-native-template-typescript
cd DoseLogic
```

### 2. Replace the generated files with this codebase

Copy everything from this folder INTO your new `DoseLogic/` project folder.
Replace `App.tsx`, `package.json`, `tsconfig.json`, `babel.config.js` and add the `src/` folder.

### 3. Install dependencies

```bash
npm install
```

### 4. Install iOS pods

```bash
cd ios && pod install && cd ..
```

### 5. Run on iPhone Simulator

```bash
npx react-native run-ios
```

To run on a **specific simulator**:
```bash
npx react-native run-ios --simulator="iPhone 15 Pro"
```

### 6. Run on a real iPhone

1. Open `ios/DoseLogic.xcworkspace` in Xcode
2. Select your iPhone in the top device bar
3. Go to **Signing & Capabilities** → select your Apple ID team
4. Press the ▶ Run button

You'll need a free Apple Developer account (sign in with Apple ID in Xcode).
A **paid account ($99/yr)** is only required to publish to the App Store.

---

## App Store Publishing (when ready)

1. Create an app record at https://appstoreconnect.apple.com
2. In Xcode: **Product → Archive**
3. Click **Distribute App → App Store Connect**
4. Submit for review (Apple reviews in 1–3 days)

---

## Customizing the app

### Add a new supplement
Open `src/data/supplements.ts` and add to the `SUPPLEMENTS` array:

```ts
{
  id: 'mysupp',
  name: 'My Supplement',
  cat: 'vitamin',       // vitamin | mineral | weight | gym | amino | nootropic | sarm | peptide
  unit: 'mg',
  defaultDose: 500,
  ul: 2000,             // null if no upper limit
  nutrients: { vitaminC: 500 },  // maps to NUTRIENT_REFS keys
  interactions: ['vitb12'],      // ids of supplements that interact
  description: 'What this supplement does.',
},
```

### Add a new interaction rule
In the `INTERACTIONS` object in `supplements.ts`:

```ts
[key('mysupp', 'vitb12')]: {
  sev: 'warn',   // 'ok' | 'warn' | 'danger'
  text: 'Description of the interaction.',
},
```

### Change colors
All colors are in `src/theme/index.ts`. Edit `Colors` object.

---

## Tech stack

| Package | Purpose |
|---------|---------|
| `react-native` 0.73 | Core framework |
| `@react-navigation/bottom-tabs` | Tab bar |
| `@react-native-async-storage/async-storage` | Persisted stack storage |
| `react-native-safe-area-context` | iPhone notch/home bar handling |
| `react-native-gesture-handler` | Gesture support |
| TypeScript | Type safety throughout |

---

## Troubleshooting

**Pod install fails:**
```bash
sudo arch -x86_64 gem install ffi
cd ios && arch -x86_64 pod install
```

**Metro bundler port conflict:**
```bash
npx react-native start --port 8082
```

**Xcode signing error:**
Go to Signing & Capabilities, enable "Automatically manage signing", select your team.

**App crashes on launch:**
```bash
npx react-native log-ios
```
This shows the crash log in real time.

---

Built with ❤️ by DoseLogic
